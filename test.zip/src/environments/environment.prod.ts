export const environment = {
  production: false,
  fileName: '../assets/product.json',
  datatable: '../../assets/datatable.json',
  insights: '../../assets/insights.json'
};
