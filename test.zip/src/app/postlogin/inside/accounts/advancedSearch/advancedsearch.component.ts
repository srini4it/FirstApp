import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { Params } from '@angular/router';
import { Component, OnInit, ViewChild, Renderer, Renderer2, ElementRef, HostListener } from '@angular/core';
import { IsUnsedParameterPipe } from './isUnsedParameter.pipe';
import { SSL_OP_ALL } from 'constants';
export interface OptionLists {
  key: string;
  name: string;
  type?: string;
  minlength?: string;
  maxlength?: string;
  placeholder?: string;
  allowMultiple?: boolean;
  suggestedValues?: Array<any>;
  restrictToSuggestedValues?: boolean;
  index?: number;
  value?: string;
  option?: string;
}
@Component({
  selector: 'app-advancedsearch',
  templateUrl: './advancedsearch.component.html',
  styleUrls: ['./advancedsearch.component.css']
})
export class AdvancedSearchComponent implements OnInit {
  focus = false;
  form: FormGroup;
  searchPlaceholder = 'Search Advanced';
  parametersLabel = 'Parameter Suggestions';
  parameters: OptionLists[];
  searchParams = [];
  changeBuffer = [];
  searchQuery = '';
  selectOption = [{ value: 'chennai', label: 'Chennai' }, { value: 'trichy', label: 'Trichy' }];
  constructor(private renderer: Renderer, private el: ElementRef, private isUnused: IsUnsedParameterPipe, private fb: FormBuilder) {
  }

  // get searchFormArray() {
  //   return <FormArray>this.form.get('searchArray');
  // }
  ngOnInit(): void {
    this.parameters = [
      { key: 'name', name: 'Name', type: 'text', placeholder: 'Name', value: 'saranagn', minlength: '5', maxlength: '10' },
      { key: 'city', name: 'City', type: 'dropdown', placeholder: 'City', restrictToSuggestedValues: false, suggestedValues: this.selectOption, value: 'chennai' },
      { key: 'email', name: 'E-Mail', type: 'text', placeholder: 'E-Mail', allowMultiple: true }
    ];
    // this.form = this.fb.group({
    //   searchArray: this.fb.array([])
    // });
    const jobGroup: FormGroup = new FormGroup({});

    // []
    // for (const obj of this.parameters) {
    //   this.searchFormArray.push(this.fb.group({
    //     key: obj.key,
    //     name: obj.name
    //   }));
    // }

    // for (const obj of this.parameters) {
    //   console.log(obj);
    // }
    // { }
    // for (const key in this.parameters) {
    //   if (this.parameters.hasOwnProperty(key)) {
    //     // const control: FormControl = new FormControl(this.parameters[key].key, Validators.required);
    //     // jobGroup.addControl(key, control);
    //     // this.searchFormArray.push(this.fb.group({
    //     //   key: this.parameters[key].key,
    //     // }));
    //     console.log(key);
    //   }
    // }

    // this.form = this.formBuilder.group({
    //   dynamicFormName: this.newFormGroup()
    // });
    // this.form = this.formBuilder.group({
    //   name: [null, [Validators.required, Validators.minLength(6)]],
    //   city: [null, [Validators.required]],
    //   email: [null, [Validators.required, Validators.minLength(6)]],
    // });
  }
  addSearchParam(searchParam, value, enterEditModel) {
    if (enterEditModel === undefined) {
      enterEditModel = true;
    }
    if (!this.IsUnsedParameter(searchParam)) {
      return;
    }
    let internalIndex = 0;
    if (searchParam.allowMultiple) {
      internalIndex = this.searchParams.filter(data => data.key === searchParam.key).length;
    }
    const newIndex =
      this.searchParams.push({
        key: searchParam.key,
        name: searchParam.name,
        type: searchParam.type || 'text',
        placeholder: searchParam.placeholder,
        allowMultiple: searchParam.allowMultiple || false,
        suggestedValues: searchParam.suggestedValues || [],
        restrictToSuggestedValues: searchParam.restrictToSuggestedValues || false,
        index: internalIndex,
        value: searchParam.value || ''
      }) - 1;

    this.updateModel('add', searchParam.key, internalIndex, value);
  }
  updateModel(command, key, index, value) {
    // this.changeBuffer = this.changeBuffer.filter(change => change.key !== key && change.index !== index);
    // this.form = this.formBuilder.group({
    //   dynamicFormName: this.newFormGroup()
    // });
    // this.isUnused.searchDataFilter(this.searchParams);
    this.changeBuffer.push({
      command: command,
      key: key,
      index: index,
      value: value
    });
    this.changeBuffer.forEach((element, i) => {
      const searchParam = this.parameters.filter(param => param.key === key)[0];
      console.log('searchParam', searchParam);
    });
  }

  IsUnsedParameter(value) {
    return this.searchParams.filter(param => param.key === value.key && !param.allowMultiple).length === 0;

  }
  appFocusinput(element) {
    element.target.focus();
  }
  removeSearchParam(data) {
    if (data !== -1) {
      this.searchParams.splice(data, 1);
    }
  }
  leaveEditMode(element, index) {
    if (index === undefined) {
      return;
    }
    const searchParam = this.searchParams[index];
    searchParam.editMode = false;
    if (element.target.localName !== 'mat-select') {
      if (!element.target.value) {
        this.removeSearchParam(index);
      }
    }

  }
  allowEditMode(element, index) {

  }

  getErrorMessage() {
    // return this.email.hasError('required') ? 'You must enter a value' :
    //   this.email.hasError('email') ? 'Not a valid email' :
    //     '';
  }
  // newFormGroup(): any {
  //   let formgroupFields: any = {};
  //   this.searchParams.forEach((item, index) => {

  //     console.log(item);
  //     formgroupFields[item.key] = new FormControl('');
  //   });
  //   return new FormGroup(formgroupFields);
  // }
}
