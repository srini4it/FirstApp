import { Directive, Renderer, ElementRef, Input, OnInit, AfterViewInit, Inject, OnChanges } from '@angular/core';

@Directive({
  selector: '[appAutoFocus]'
})
export class AutoFocusDirective implements OnInit {
  constructor(@Inject(ElementRef) private element: ElementRef) { }

  ngOnInit(): void {
    setTimeout(() => {
    this.element.nativeElement.focus();
    this.element.nativeElement.click();
    }, 1);
  }
}
